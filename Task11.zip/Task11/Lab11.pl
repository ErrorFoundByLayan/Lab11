letters([a,b,c]).


display_letters :-
    letters(L),
    write('Current letters: '),
    write(L), nl.


add_letter(Letter, Position, List, NewList) :-
    length(List, Len),
    Position > 0,
    Position =< Len + 1,
    N is Position - 1,
    length(First, N),
    append(First, Rest, List),
    append(First, [Letter|Rest], NewList).


add_top(Letter, List, [Letter|List]).


add_bottom(Letter, List, NewList) :-
    append(List, [Letter], NewList).


delete_letter(_, [], []).
delete_letter(Letter, [Letter|T], T).
delete_letter(Letter, [H|T], [H|NewT]) :-
    Letter \= H,
    delete_letter(Letter, T, NewT).

delete_all([]).

start :-
    letters(L),
    menu(L).

menu(L) :-
    nl,
    write('1- Display the current set of letters'), nl,
    write('2- Add a letter at a specific position'), nl,
    write('3- Add a letter at the top'), nl,
    write('4- Add a letter at the bottom'), nl,
    write('5- Delete a letter'), nl,
    write('6- Delete all letters'), nl,
    write('7- Exit'), nl,
    write('Enter your choice: '),
    read(Choice),
    action(Choice, L).

action(1, L) :-
    write('Current letters: '), write(L), nl,
    menu(L).

action(2, L) :-
    write('Enter letter: '), read(X),
    write('Enter position: '), read(P),
    (add_letter(X, P, L, NewL) ->
        menu(NewL)
    ;
        write('Invalid position'), nl,
        menu(L)
    ).

action(3, L) :-
    write('Enter letter: '), read(X),
    add_top(X, L, NewL),
    menu(NewL).

action(4, L) :-
    write('Enter letter: '), read(X),
    add_bottom(X, L, NewL),
    menu(NewL).

action(5, L) :-
    write('Enter letter to delete: '), read(X),
    delete_letter(X, L, NewL),
    menu(NewL).

action(6, _) :-
    menu([]).

action(7, _) :-
    write('Goodbye!'), nl.

action(_, L) :-
    write('Invalid choice!'), nl,
    menu(L).